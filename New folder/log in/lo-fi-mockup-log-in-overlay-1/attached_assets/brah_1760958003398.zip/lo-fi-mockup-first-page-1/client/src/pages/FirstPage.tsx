import React from "react";
import { Button } from "@/components/ui/button";
import { PhilippinesMap } from "@/components/PhilippinesMap";

export const FirstPage = (): JSX.Element => {
  const handleAboutClick = () => {
    const aboutSection = document.getElementById('about-section');
    aboutSection?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleLoginClick = () => {
    alert('Login functionality coming soon!');
  };

  return (
    <div className="bg-white w-full min-h-screen">
      {/* Fixed Header with iReady Logo */}
      <header className="fixed top-0 left-0 w-full h-16 md:h-20 lg:h-24 z-50 bg-white">
        <img
          className="w-full h-full object-cover"
          alt="iReady Header"
          src="/figmaAssets/fixed.png"
        />
      </header>

      {/* Navigation Overlay */}
      <nav className="fixed top-0 right-0 z-[60] flex gap-3 md:gap-4 pr-4 md:pr-8 pt-3 md:pt-4 lg:pt-6">
        <Button 
          onClick={handleAboutClick}
          className="h-10 md:h-12 px-4 md:px-6 bg-gray-700 rounded-full hover:bg-gray-600 text-sm md:text-base"
        >
          About
        </Button>
        <Button 
          onClick={handleLoginClick}
          className="h-10 md:h-12 px-4 md:px-6 bg-blue-600 rounded-full hover:bg-blue-700 text-sm md:text-base"
        >
          Log in
        </Button>
      </nav>

      {/* Main Content - Below Fixed Header */}
      <main className="pt-16 md:pt-20 lg:pt-24">
        {/* Hero Section: Map + Info Panel */}
        <section className="flex flex-col lg:flex-row min-h-[500px] md:min-h-[600px]">
          {/* Map Container - Takes up ~70% width on large screens, full width on mobile */}
          <div className="w-full lg:w-[70%] h-[400px] md:h-[500px] lg:h-[600px]">
            <PhilippinesMap className="w-full h-full" />
          </div>

          {/* Right Info Panel - Takes up ~30% width on large screens */}
          <div className="w-full lg:w-[30%] flex flex-col gap-4 p-4 md:p-6 bg-gray-50">
            {/* Call to Action Card */}
            <div className="bg-gray-200 rounded-2xl p-6 md:p-8">
              <h2 className="text-2xl md:text-3xl font-bold mb-4">
                Let's Prepare Now!
              </h2>
              <p className="text-sm md:text-base text-gray-700 mb-6">
                Collaborate with other units as you all aim to reach a common goal, help those in need.
              </p>
              <Button 
                onClick={handleLoginClick}
                className="w-full h-12 bg-gray-900 rounded-lg hover:bg-gray-800 text-sm md:text-base font-semibold"
              >
                LOG IN
              </Button>
            </div>

            {/* Current Updates Card */}
            <div className="bg-gray-200 rounded-2xl p-6 md:p-8">
              <h3 className="text-lg md:text-xl font-bold">
                Current updates on that map/baranggay
              </h3>
            </div>
          </div>
        </section>

        {/* Info About iReady Section */}
        <section 
          id="about-section" 
          className="bg-black text-white py-16 md:py-24 px-6 md:px-16"
        >
          <h2 className="text-4xl md:text-6xl lg:text-7xl font-bold uppercase">
            Info about iReady
          </h2>
        </section>

        {/* Contact Info Section */}
        <section className="bg-white py-16 md:py-24 px-6 md:px-16">
          <h2 className="text-4xl md:text-6xl lg:text-7xl font-bold uppercase">
            Contact Info
          </h2>
        </section>
      </main>
    </div>
  );
};
